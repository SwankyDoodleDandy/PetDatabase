/*
This is a program for CSC 422 regarding the creation of a pet database. The adding 
and removing of pets. 
 */
package petdatabase;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Nolan Harre
 */
public class PetDatabase {

    public static void main(String[] args) {
        int option;
        boolean flag = true;
        Scanner input = new Scanner(System.in);
        ArrayList<pet> pets = new ArrayList<>();
        String newName = null;
        int newAge = 0;
        int ID = 0;
        int count;
        
        System.out.print("Pet Database Program\n");
        
        while (flag){
            printOptions();
            option = input.nextInt();
            
            if(option == 7){
                flag = false;
            }
            else if(option == 1){
                count = 0;
                System.out.print(pets + "\n");
                printTableHeader();
                for(int i = 0; i < pets.size(); i++){
                    pet newPet = new pet();
                    newPet = pets.get(i);
                    System.out.printf("|%3d | %-10s|%4d |%n",newPet.getID(), newPet.getName(), newPet.getAge());
                    count++;
                }
                System.out.print("+----------------------+\n" + count + 
                            " rows in set.\n");
                
            }
            else if(option == 2){
                while(!"done".equals(newName)){
                    count = 0;
                    System.out.print("add pet(name, age): ");
                    newName = input.next();
                    if ("done".equals(newName)){
                        System.out.print(count + " pets added\n");
                        break;
                    }
                    else{
                        pet newPet = new pet();
                        newAge = input.nextInt();
                        newPet.setAge(newAge);
                        newPet.setName(newName);
                        newPet.setID(pets.size());
                        pets.add(newPet);
                        count++;
                    }
                    
                }
            }
        }
    }
    
    public static void printTableHeader(){
        System.out.print("+----------------------+\n" + "| ID | NAME      | AGE |\n"
        + "+----------------------+\n");
    }
    
    public static void printOptions(){
        System.out.print("What would you like to do?\n" +
                "1) View All Pets\n" +
                "2) Add More Pets\n" +
                "3) Update An Existing Pet\n" +
                "4) Remove An Existing Pet\n" +
                "5) Search Pets By Name\n" +
                "6) Search Pets By Age\n" +
                "7) Exit Program\n" +
                "Your Choice: ");
    }
}
