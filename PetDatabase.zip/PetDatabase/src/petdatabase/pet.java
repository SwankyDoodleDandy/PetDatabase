package petdatabase;

/**
 * @author Nolan Harre
 */
public class pet {
    int ID;
    int age;
    String name;
    
    public pet(){
        
    }
    
    public pet(int x, String y){
        age = x;
        name = y;
        ID = 0;
    }
    
    public int getAge(){
        return age;
    }
    public void setAge(int x){
        this.age = x;
    }
    
    public String getName(){
        return name;
    }
    public void setName(String x){
        this.name = x;
    }
    
    public int getID(){
        return ID;
    }
    public void setID(int x){
        this.ID = x;
    }
    
}
